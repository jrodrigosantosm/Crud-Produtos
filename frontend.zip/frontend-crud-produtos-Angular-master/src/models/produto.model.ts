export interface Produto{

   id?: number,
   nome: string,
   categoria: string,
   valor: number,
   dataVencimento: string,
   estoque: number,
   perecivel: boolean

}
