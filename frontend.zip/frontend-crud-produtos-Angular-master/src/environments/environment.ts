export const environment = {
  api: '',
};
